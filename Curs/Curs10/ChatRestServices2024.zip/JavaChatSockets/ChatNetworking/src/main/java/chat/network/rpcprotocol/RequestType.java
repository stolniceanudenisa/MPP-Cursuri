package chat.network.rpcprotocol;

/**
 * Created by grigo on 12/15/15.
 */
public enum RequestType {
    LOGIN, LOGOUT, GET_LOGGED_FRIENDS, SEND_MESSAGE;
}
