package tasks.utils;

/**
 * Created by grigo on 11/16/16.
 */
public enum STEType {
    ADD,DELETE,UPDATE
}
