package chat.notification;

/**
 * Created by grigo on 5/2/17.
 */
public enum NotificationType {
    USER_LOGGED_IN, USER_LOGGED_OUT, NEW_MESSAGE
}
