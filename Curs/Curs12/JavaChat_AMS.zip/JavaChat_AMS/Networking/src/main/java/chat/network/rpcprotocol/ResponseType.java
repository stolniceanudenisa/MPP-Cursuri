package chat.network.rpcprotocol;

/**
 * Created by grigo on 12/15/15.
 */
public enum ResponseType {
    OK, ERROR, GET_LOGGED_USERS,UPDATE, NEW_MESSAGE, USER_LOGGED_IN, USER_LOGGED_OUT;
}
