package chat.persistence;

import chat.model.Message;


public interface MessageRepository extends ICrudRepository<Integer, Message> {
}
